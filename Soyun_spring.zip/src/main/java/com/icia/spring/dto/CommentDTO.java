package com.icia.spring.dto;

import lombok.Data;

@Data
public class CommentDTO {
	private int cnumber;
	private int cbnumber;
	private String cwriter;
	private String ccontents;
}
