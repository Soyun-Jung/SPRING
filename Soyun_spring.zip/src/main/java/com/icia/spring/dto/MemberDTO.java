package com.icia.spring.dto;

import lombok.Data;

@Data
public class MemberDTO {
	private String mid;
	private String mpwd;
	private String mname;
	private String mbirth;
	private String mnumber;
	private String memail;
	private String madd;
	private String mpostcode;
	private String mroadadd;
	private String mjibunadd;
	private String mdetailadd;
	private String mextraadd;
}
