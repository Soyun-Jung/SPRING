package com.icia.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.icia.board.dao.BoardDAO;
import com.icia.board.dto.BoardDTO;

@Service
public class BoardService {
	@Autowired
	private BoardDAO bdao;
	
	private ModelAndView mav;
	
	public ModelAndView boardWrite(BoardDTO board) {
		mav = new ModelAndView();
		int writeResult = bdao.boardWrite(board);
		// 글쓰기 성공시 글목록 출력 
		if(writeResult > 0)
			mav.setViewName("redirect:/boardlist");
		else
			mav.setViewName("boardv/WriteFail");
		return mav;
	}

	public ModelAndView boardList() {
		mav = new ModelAndView();
		List<BoardDTO> boardList = bdao.boardList();
		mav.addObject("boardList", boardList);
		mav.setViewName("boardv/BoardList");
		return mav;
	}

	public ModelAndView boardView(int bnumber) {
		mav = new ModelAndView();
		// 1. 조회수 올리기
		// 2. 글 상세내용 가져오기
		bdao.boardHits(bnumber);
		
		BoardDTO boardView = bdao.boardView(bnumber);
		mav.addObject("boardView", boardView);
		mav.setViewName("boardv/BoardView");
		return mav;
	}

	public ModelAndView boardUpdate(int bnumber) {
		mav = new ModelAndView();
		BoardDTO boardUpdate = bdao.boardView(bnumber);
		mav.addObject("boardUpdate", boardUpdate);
		mav.setViewName("boardv/BoardUpdate");
		return mav;
	}

	public ModelAndView boardUpdateProcess(BoardDTO board) {
		mav = new ModelAndView();
		int updateResult = bdao.boardUpdate(board);
		if(updateResult>0) {
			// 1. 목록으로 가기
//			mav.setViewName("redirect:/boardlist");
			// 2. 수정이 완료된 글 상세화면 출력  
			mav.setViewName("redirect:/boardview?bnumber="+board.getBnumber());
		} else {
			mav.setViewName("boardv/BoardUpdateFail");
		}
			
		return mav;
	}

}












